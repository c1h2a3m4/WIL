﻿internal class IndentityOptions
{
}